SCHAF & SCHNITT – iPhone-Web-App

Enthalten: index.html, manifest.webmanifest, sw.js sowie App-Symbole.

WICHTIG: Für „Zum Home-Bildschirm“ als installierbare PWA muss das Paket zuerst über HTTPS veröffentlicht werden. Eine ZIP-Datei allein kann iOS nicht als App installieren.

Einfacher Weg:
1. Lade den ZIP-Ordner auf einen HTTPS-Webhost deiner Wahl hoch (z. B. GitHub Pages oder Netlify).
2. Öffne danach die veröffentlichte HTTPS-Adresse in Safari auf dem iPhone.
3. Tippe auf Teilen (Quadrat mit Pfeil nach oben) → „Zum Home-Bildschirm“ → „Hinzufügen“.
4. Starte „Schaf & Schnitt“ über das neue Symbol. Der Spielstand wird lokal auf dem iPhone gespeichert.

Das Spiel läuft auch direkt als index.html im Browser zum Testen; Offline-/Home-Bildschirm-Funktionen benötigen HTTPS und Service Worker.
